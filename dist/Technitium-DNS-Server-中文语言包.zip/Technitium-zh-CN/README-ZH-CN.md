# Technitium DNS Server 简体中文语言包

这是 Technitium DNS Server Web 管理控制台的简体中文汉化补丁。它只在浏览器端翻译界面文字，不改 DNS 服务、不改配置文件、不碰查询日志和缓存数据。

## 已汉化的范围

- 顶部导航、侧边栏、仪表盘卡片、图表图例
- 区域、缓存、允许/拦截列表、DHCP、应用、管理、日志、关于等页面
- 设置页的标签、选项、按钮、常见提示
- 登录页、修改密码、两步验证、用户/用户组等管理界面
- 约 1700 条长段/中短帮助说明和界面文案（其中 419 条按 `index.html` 与 UI JS 源码逐条补齐）
- 应用商店 27 个应用的名称和简介，以及应用页“已安装应用”的名称和简介（按当前商店目录建立中文词典）
- 常见删除、停用、重新同步、2FA 等确认弹窗，会在弹出前翻译标题和正文

源码级审计结果：`index.html` 未命中候选从 198 条降到 43 条，UI JS 纯文本候选从 480 条降到约 174 条；剩余主要是示例域名/IP、协议缩写、文件路径、API 报错和日志正文。

应用商店的简介是第三方动态内容，目前按现有 27 个应用逐条翻译；以后新上架或应用更新改了简介，会先显示英文原文，需要补词典。

## 没有汉化的部分

- Technitium 服务端 C# 返回的错误信息（例如 API 报错）
- 查询日志正文、DNS 记录内容、用户自己填写的名称
- API 文档、GitHub 页面
- `DNS`、`DNSSEC`、`DoH`、`DoT`、`TTL`、`SOA`、`NSEC3` 等技术缩写保持英文，方便对照文档

长段帮助文字使用机器翻译辅助生成，已经做过技术名词校对；如果发现语句别扭，可以直接改 `i18n-zh-help.js` 里对应的中文。

## 文件说明

- `i18n-zh.js`：运行时翻译逻辑 + 常用界面词典
- `i18n-zh-help.js`：长段/中短帮助文字词典
- `i18n-zh-apps.js`：应用商店应用名称和简介词典，并在应用商店弹窗加载后翻译
- 安装时在 `www/index.html` 的 `</body>` 前加三行脚本引用

## 安装到已运行的 Technitium

先备份安装目录里的 `www`（至少备份 `index.html`），然后把三个 JS 文件复制到：

```text
C:\Program Files (x86)\Technitium\DNS Server\www\js\
```

再编辑 `C:\Program Files (x86)\Technitium\DNS Server\www\index.html`，在 `</body>` 前加入：

```html
<script src="js/i18n-zh-help.js"></script>
<script src="js/i18n-zh-apps.js"></script>
<script src="js/i18n-zh.js"></script>
```

保存后回到浏览器按 `Ctrl + F5` 强制刷新。服务不用重启。

## 回滚

1. 删除 `www\index.html` 里的三行 `i18n-zh*.js` 引用。
2. 删除 `www\js\i18n-zh.js`、`www\js\i18n-zh-help.js` 和 `www\js\i18n-zh-apps.js`。
3. 或者直接用安装时备份的 `index.html.bak-zh-*` 覆盖回去。

## 升级注意

Technitium 升级时会覆盖 `www` 目录，汉化会丢失。升级后把三个 JS 文件和 `index.html` 的三行引用重新加回去即可。

## 许可

本补丁基于 Technitium DNS Server 源码修改，原项目使用 GPLv3，本补丁同样按 GPLv3 分发。原项目版权归 Technitium Software 所有。
